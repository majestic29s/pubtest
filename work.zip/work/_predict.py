#!/usr/bin/env python
# -*- coding: utf-8 -*-
import time,os
import pandas as pd
from sklearn.externals import joblib

codes = [
    1357, 1570, 2038, 1321, 1459,
    1552, 1571, 1458, 1366, 1320,
    1671, 1540, 1365, 2035, 8963,
    1346, 4689, 5020, 8308, 2768,
    4755, 9501, 8002, 1332, 4188,
    4005, 5703, 2337, 6629, 8593,
    8572, 3482, 1821
]


def main3():
    for code in codes:
        df = pd.read_csv(r'c:/temp/observation-data/' + str(code) + '.csv')

        X = df.iloc[-1:, 2:30]  #最終行を取得
        #保存済みモデルの利用
        print("model loading ..")
        loaded_model = joblib.load(r'c:/temp/learned-models/forest_' + str(code) + '.pkl')
        print(str(code) + " : 株価予測中...")
        predict = loaded_model.predict(X.values.reshape(1, -1)) #列を行に変換する。

        date = df.iloc[-1, 1]
        zen = date + 'に基づく２日後, ' + str(code) + "の株価は "

        if predict[0] == 0:
            print(zen + "落下又は現状維持")
        else:
            print(zen + "上昇!")
        exit()

if __name__ == "__main__":
    main3()
