#!/usr/bin/env python
# -*- coding: utf-8 -*-
import time,os
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from sklearn.externals import joblib
from sklearn.model_selection import GridSearchCV
import json

codes = [
    1357, 1570, 2038, 1321, 1459,
    1552, 1571, 1458, 1366, 1320,
    1671, 1540, 1365, 2035, 8963,
    1346, 4689, 5020, 8308, 2768,
    4755, 9501, 8002, 1332, 4188,
    4005, 5703, 2337, 6629, 8593,
    8572, 3482, 1821
]


search_params = {
    'n_estimators' : [10, 20, 30, 40, 50, 100, 200, 300],
    'max_features': [None, 'auto', 'log2'],
    'max_depth': [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
    'class_weight': [None, 'balanced'],
    'random_state' : [42]
    }

def main3():
    for code in codes:
        df = pd.read_csv(r'c:/temp/observation-data/' + str(code) + '.csv')

        df = df.dropna(subset=['target'])#targetに欠損値のある行を削除
        df = df.fillna(df.mean())#欠損値を劣後tの平均値で埋める

        X = df.iloc[:, 2:30]
        y = df.iloc[:, 30]
        X_train,X_test,y_train,y_test = train_test_split(X,y)

        #学習宇モデルの構築
        forest = RandomForestClassifier()
        grid = GridSearchCV(forest, search_params, cv=3)
        grid.fit(X_train, y_train)

        #学習結果表示
        print("Grid-Search with accuray")
        print("Best parameters:", grid.best_params_)
        print("Test set score {:.2f} ".format(grid.score(X_test, y_test)))

        joblib.dump(grid.best_estimator_,r"C:\temp\learned-models\forest_" + str(code) + ".pkl")

        print(str(code) + " : モデル保存完了")

if __name__ == "__main__":
    main3()
