#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests
import time,os
import pandas as pd

years = [2017, 2018, 2019]
up = 1
ago = 3
codes = [
    1357, 1570, 2038, 1321, 1459,
    1552, 1571, 1458, 1366, 1320,
    1671, 1540, 1365, 2035, 8963,
    1346, 4689, 5020, 8308, 2768,
    4755, 9501, 8002, 1332, 4188,
    4005, 5703, 2337, 6629, 8593,
    8572, 3482, 1821
]

etf_list = [
    1305, 1306, 1309, 1326, 1343,
    1543, 1545, 1551, 1633, 1655,
    1656, 1659, 1678, 1682, 1682
]

def get_csv(code, year):
    df = pd.read_csv(r'c:/temp/dataset/' + str(code) + "_" + str(year) + '.csv', encoding='shift-jis', header=1)
    df.columns = ['Date', 'Open', 'High', 'Low', 'Close', 'Volume', "Trading Value"]
    return df

def create_dataset(code, year):
    list = []
    for year in years:
        list.append(get_csv(code, year))
    df1 = pd.concat(list)
    df1.reset_index(inplace=True, drop=True)
    return df1

def calc_diff(df, code):
    diff_lists = []
    for eo, ec in zip(df['Open'], df['Close']):
        diff_p = round((ec - eo) / ec * 100, 2)
        diff_lists.append(diff_p)
    df['diff_' + str(code)] = diff_lists
    return df


def main3():

    print("株価のデータセットを作る")

    for code in codes:
        df_dataset = create_dataset(code, years)

        for x in range(len(df_dataset)):
            EO = df_dataset.loc[x, "Open"]
            EC = df_dataset.loc[x, 'Trading Value']
            diff_p = round((EC - EO) / EC * 100, 2)
            df_dataset.loc[x, 'ratio'] = diff_p

        for i in range(1, ago + 1):
            for x in range(len(df_dataset)):
                if x < i:
                    continue
                diff = df_dataset.loc[x - i, 'ratio']
                volume = df_dataset.loc[x - i, 'Volume']
                df_dataset.loc[x, 'ago_ratio' + str(i)] = diff
                df_dataset.loc[x, 'ago_volume' + str(i)] = volume

        for etf in etf_list:
            iname = '_' + str(etf)
            df_etf = create_dataset(etf, years)
            df_etf = calc_diff(df_etf, etf)
            etf_toraku = df_etf.loc[:, ['Date', 'diff_' + str(etf)]]
            df_dataset = pd.merge(df_dataset, etf_toraku, on='Date', how='left')


        for x in range(len(df_dataset)):
            if x >= len(df_dataset) - 2:
                target = ""
                df_dataset.loc[x, 'target'] = target
                continue

            TC = df_dataset.loc[x, 'Open']
            EC = df_dataset.loc[x + 2, 'Close']
            diff_p = (TC - EC) / TC * 100

            target = 0
            if diff_p >= up:
                target = 1
            else:
                target = 0
            df_dataset.loc[x,'target'] = target
        print(str(code) + "のcsv保存")
        df_dataset.to_csv(r'c:/temp/observation-data/' + str(code) + '.csv')

if __name__ == "__main__":
    main3()
