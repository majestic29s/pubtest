#!/usr/bin/env python
# -*- coding: utf-8 -*-
#%matplotlib inline
import numpy as np
#import statsmodels.api as sm
#import matplotlib.pyplot as plt
import pandas as pd
import pandas.tseries as pdt
from datetime import date
import common
import datetime
import os,csv,sys
import shutil
sys.path.append(common.LIB_DIR)
import common_profit as compf
import str_breakout_test as breakout

class profit:
    def __init__(self,num):
        t = datetime.datetime.now()
        self.date = t.strftime("%Y%m%d%H%M%S")
        #保存フォルダルート
        self.S_DIR = os.path.join(r"C:\data\90_profit\06_output",num,self.date + "_FX")
        #保存フォルダ
        self.INPUT_DIR = r"C:\data\90_profit\05_input\FX"
        os.mkdir(str(self.S_DIR))
        #編集ファイル格納場所（通常は使用しない)
        self.dir = r"C:\data\90_profit\05_input\FX_soruce"
        #本スクリプトコピー
        shutil.copy2(__file__, self.S_DIR)

    def M15_stg(self,ETF,priod = 'M'):
        t = datetime.datetime.now()
    #時間指定ネタ
    #    sql_pd = pd.read_csv( 'USDJPY_15.csv',index_col=0,parse_dates=True)
    #    td=sql_pd[sql_pd.index.hour==8]
        for code in ETF:
    #        sql_pd = info.csv_connect(info.dir + "//" + code ,code)#★★★★★★★
    #        para =[ i for i in range(24)]
            sql_pd = breakout.priod_edit2(code, priod)
    #        sql_pd = pd.read_csv(os.path.join(info.INPUT_DIR ,'AUDJPY_100_2.5_1BacktestReport.csv'),index_col=0,parse_dates=True)#●●●●●●●●●●●
    #        aaa = sql_pd[(sql_pd['ShortPL'] != 0.0) | (sql_pd['LongPL'] != 0.0)]
            if len(sql_pd) > 500:
                for i in range(2,350,50):
                    window = i
                    multi = 2.5
                    title = code + "_" + str(window) + "_" + str(multi) + "_ma_std.csv"
                    PL = breakout.ma_std(window, multi, sql_pd, code)
                    Equity, backreport = compf.BacktestReport(PL, title, info.S_DIR)
                for i in range(2, 200, 20):
                    for ii in range(2, 400, 50):
                        window0 = i
                        window9 = ii
                        if i == ii:
                            continue
                        title = code + "_" + str(window0) + "_" + str(window9) + "_ma_two.csv"
                        PL = breakout.ma_two(window0, window9, sql_pd, code)
                        Equity, backreport = compf.BacktestReport(PL, title,info.S_DIR)

                for i in range(1, 300, 30):
                    for ii in range(50, 2000, 100):
                        for iii in range(300, 3000, 300):
                            window0 = i
                            window5 = ii
                            window9 = iii
                            if i < ii < iii or i > ii > iii:
                                title = code + "_" + str(window0) + "_" + str(window5) + "_" + str(window9) + "_ma_three.csv"
                                PL = breakout.ma_three(window0, window5, window9, sql_pd, code)
                                Equity, backreport = compf.BacktestReport(PL, title,info.S_DIR)
                for i in range(5, 100, 10):
                    for ii in range(10, 300, 30):
                        for iii in range(50, 2000, 100):
                            for iiii in range(500, 5000, 500):
                                window0 = i
                                window5 = ii
                                window9 = iii
                                window10 = iiii
                                if i > ii > iii > iiii or i < ii < iii < iiii:
                                    title = code + "_" + str(window0) + "_" + str(window5) + "_" + str(window9) + "_" + str(window10) + "_ma_four.csv"
                                    PL = breakout.ma_four(window0, window5, window9,window10, sql_pd, code)
                                    Equity, backreport = compf.BacktestReport(PL, title, info.S_DIR)

                for i in range(2, 200, 50):
                    for ii in range(2, 100, 20):
                        window0 = i
                        window9 = ii
                        if i == ii:
                            continue
                        title = code + "_" + str(window0) + "_" + str(window9) + "_simple.csv"
                        PL = breakout.simple(window0, window9, sql_pd, code)
                        Equity, backreport = compf.BacktestReport(PL, title,info.S_DIR)

                for i in range(2, 200, 50):
                    for ii in range(2, 100, 20):
                        for iii in range(2, 100, 20):
                            for iiii in range(2, 400, 50):
                                window0 = i
                                window9 = ii
                                f0 = iii
                                f9 = iiii
                                if i == ii or iii == iiii:
                                    continue
                                title = code + "_" + str(window0) + "_" + str(window9) + "_" + str(f0) + "_" + str(f9) + "_simple_f.csv"
                                PL = breakout.simple_f(window0, window9, f0, f9, sql_pd, code)
                                Equity, backreport = compf.BacktestReport(PL, title,info.S_DIR)
        sum_time = datetime.datetime.now() - t
        print(t,datetime.datetime.now(),sum_time)


if __name__ == "__main__":
    t = datetime.datetime.now()
    info = profit('FX')
    ETF = [ 'BTCJPY','GBPJPY','AUDJPY', 'USDJPY', 'EURJPY','AUDUSD', 'GBPUSD', 'EURUSD']
#    ETF = ['topixL', 'J225L', 'jpx400', 'mather', 'GOLD', 'GOMU', 'pura', 'WTI']
    info.M15_stg(ETF)
    """
    df = common.select_sql('B05_cfd_stg.sqlite', 'select *,rowid from _gmo_info')
    title = list(df.columns)
    ETF = []
    for code in title:
        if code.count("_") or code == 'now':
            continue
        ETF.append(code)
    info.M15_stg(ETF,"D")
    """
    print("end",__file__)
