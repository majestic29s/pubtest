#!/usr/bin/env python
# -*- coding: utf-8 -*-
import requests
import time,os
from selenium import webdriver

address = 'https://kabuoji3.com/stock/'
years = [2019, 2018, 2017]
codes = [
    1357, 1570, 2038, 1321, 1459,
    1552, 1571, 1458, 1366, 1320,
    1671, 1540, 1365, 2035, 8963,
    1346, 4689, 5020, 8308, 2768,
    4755, 9501, 8002, 1332, 4188,
    4005, 5703, 2337, 6629, 8593,
    8572, 3482, 1821,

    1305, 1306, 1309, 1326, 1343,
    1543, 1545, 1551, 1633, 1655,
    1656, 1659, 1678, 1682, 1682

]


def main3():

#    browser = webdriver.PhantomJS()
    browser = webdriver.Chrome()
    for code in codes:
        for year in years:
            path = "./dataset/" + str(code) + "_" + str(year) + ".csv"
            try:
                os.remove(path)
                print(path + "削除")
            except:
                print("対象ファイルなし")

            url = address + str(code) + "/" + str(year) + "/"

            browser.get(url)
            time.sleep(1)

            try:
                btnElem = browser.find_element_by_class_name('mt_10')
            except NoSuchElementException:
                print(str(year) + '年のCSVファイルは存在しない')
                continue
            btnElem.find_element_by_name('csv').submit()
            time.sleep(1)

            btnElem2 = browser.find_element_by_class_name('mt_10')
            btnElem2.find_element_by_name('csv').submit()
            print(str(code) + ":" + str(year) + '年  csv取得完了')
            time.sleep(1)
    browser.close()

def get_url(code, year):
    download_url = address + str(code) + "/" + str(year) + "/"
    return(download_url)


if __name__ == "__main__":
    main3()
