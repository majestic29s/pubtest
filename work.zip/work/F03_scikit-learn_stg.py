#!/usr/bin/env python
# -*- coding: utf-8 -*-
import warnings
warnings.filterwarnings('ignore')  # 実行上問題ない注意は非表示にする

# Pandasのimport
import pandas as pd
import numpy as np
import sys, os, datetime
import common

# 機械学習ライブラリ
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score, classification_report
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score

#モデルの保存・読み込み
from sklearn.externals import joblib
#import sklearn
import pickle

sys.path.append(common.LABO_DIR)
import common_sklearn as sk

class scikit_learn:
    def __init__(self,num):
        self.num = num
        self.code = ""
        self.S_DIR = common.MODEL
        self.Change = ""
        self.haba = ""

    def model3(self, code, x_data, y_data, title):  #何日分使うか決める nday
        print(x_data.shape, y_data.shape)
        X_train, X_test, y_train, y_test = train_test_split(x_data, y_data, train_size=0.8, shuffle=False)
        # 決定技モデルの訓練
        clf_2 = DecisionTreeClassifier(max_depth=5)
        # grid searchでmax_depthの最適なパラメータを決める
        #k=10のk分割交差検証も行う
        params = {'max_depth': [2, 5, 10, 20],'class_weight': ['balanced']}
        grid = GridSearchCV(estimator=clf_2,
                            param_grid=params,
                            cv=10,
                            scoring='accuracy'
                            )
        """
        grid = GridSearchCV(forest, search_params, cv=3)
        search_params = {
            'n_estimators' : [10, 20, 30, 40, 50, 100, 200, 300],
            'max_features': [None, 'auto', 'log2'],
            'max_depth': [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
            'class_weight': [None, 'balanced'],
            'random_state' : [42]
        }
        """
        grid.fit(X_train, y_train)
        for r, _ in enumerate(grid.cv_results_['mean_test_score']):
            print("%0.3f +/- %0.2f %r"
                % (grid.cv_results_['mean_test_score'][r],
                    grid.cv_results_['std_test_score'][r] / 2.0,
                    grid.cv_results_['params'][r]))
        print('Best parameters: %s' % grid.best_params_)
        print('Accuracy: %.2f' % grid.best_score_)

        #grid searchで最適だったパラメータを使って学習する
        clf_2 = grid.best_estimator_
        clf_2 = clf_2.fit(X_train, y_train)
        #モデルを保存する。
        filename = os.path.join(self.S_DIR, code.replace("/", "") + "_" +  title + "_" + str(self.Change) + "_" + str(self.haba) + "_" + '_model3.sav')
        pickle.dump(clf_2, open(filename, 'wb'))
        pred_test_2 = clf_2.predict(X_test)
        """
        #重要度の高い素性を表示
        importances = clf_2.feature_importances_
        indices = np.argsort(importances)[::-1]

        for f in range(X_train.shape[1]):
            print("%2d) %-*s %f" % (f + 1, 30,
                                    x_data.columns[1+indices[f]],
                                    importances[indices[f]]))
        """
        #テストデータ 正解率
#        print(accuracy_score(y_test, pred_test_2))
        print(classification_report(y_test, pred_test_2))
        fit_ = accuracy_score(y_test, pred_test_2)
        dict_w = {}
        dict_w['now'] = common.env_time()[1]
        dict_w['code'] = code
        dict_w['title'] = title
        dict_w['Change'] = self.Change
        dict_w['haba'] = self.haba
        dict_w.update(grid.best_params_)
        dict_w['tran'] = grid.best_score_
        dict_w['pred'] = fit_
#        dict_w['precision_score'] = precision_score(y_test, pred_test_2)
#        dict_w['recall_score'] = recall_score(y_test, pred_test_2)

        temp = classification_report(y_test, pred_test_2, output_dict=True)
        df = pd.DataFrame(classification_report(y_test, pred_test_2, output_dict=True))
        dict_w.update(df['1'].to_dict())

        filename = os.path.join(self.S_DIR, "_MODEL_SCORE.csv")
        common.save_to_csv(filename,dict_w)
        print(fit_)
        return

    def W_mente(self):
        df_info = sk.fx_data()  #いらないデータやNoneの補修など実施
        for code in ['USD/JPY', 'EUR/USD', 'EUR/JPY', 'GBP/JPY','AUD/JPY']:
            x_data_ = sk.add_avg(df_info.copy(), code)
#            x_data_ = sk.so_check(code, x_data_) #相関関係チェック
            self.haba = 0.001
            x_plus, y_plus = sk.create_y(code, x_data_.copy(), -4, info.haba)  #3引数は何日後の予測をするか？ 4引数は目的変数 0は1or-1 9999は株価
            x_mynus, y_mynus = sk.create_y(code, x_data_.copy(), -4, -info.haba)  #3引数は何日後の予測をするか？ 4引数は目的変数 0は1or-1 9999は株価
            for Change in ["MinMax"]:
                info.Change = Change
                x_mynus = sk.RateOfChange(x_mynus, info.Change, 1)
                x_plus = sk.RateOfChange(x_plus, info.Change, 1)
                info.model3(code, x_plus, y_plus,"plus")  # 1 or -1
                info.model3(code, x_mynus, y_mynus,"mynus")  # 1 or -1

    def main(self):
        df = sk.fx_data(200)
        for code in ['USD/JPY','EUR/USD','EUR/JPY','GBP/JPY','AUD/JPY']:
            dict_w = {}
            x_data = sk.add_avg(df.copy(), code)
            self.Change = 'MinMax'
            x_data = sk.RateOfChange(x_data, 'MinMax', 1)
            for ttype in ['_mynus','_plus']:
                filename = os.path.join(common.MODEL, code.replace("/", "") + ttype + '_MinMax_0.001__model3.sav') #GBPJPY_plus_MinMax_0.001__model3.sav
                clf_2 = joblib.load(filename)
                print(ttype,x_data.shape)
                print(ttype,x_data.columns)

                pred_test_2 = clf_2.predict(x_data)
                dict_w[code.replace("/","") + ttype] = pred_test_2[-1]
            print(sum(dict_w.values()))
            if sum(dict_w.values()) == 0:
                if dict_w[code.replace("/", "") + '_plus'] == 1:
                    dict_w[code.replace("/", "") + '_res'] = 1
                elif dict_w[code.replace("/", "") + '_mynus'] == 1:
                    dict_w[code.replace("/", "") + '_res'] = -1
            else:
                dict_w[code.replace("/", "") + '_res'] = 0
            sqls = common.create_update_sql('I07_fx.sqlite', dict_w, 'gmofx')

if __name__ == "__main__":
    info = scikit_learn(0)
    argvs = sys.argv
    if argvs[1] == "main":
        info.main()
    if argvs[1] == "mente":
        info.W_mente()
