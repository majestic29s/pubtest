#!/usr/bin/env python
# -*- coding: utf-8 -*-
#%matplotlib inline
import numpy as np
#import statsmodels.api as sm
#import matplotlib.pyplot as plt
import pandas as pd
import pandas.tseries as pdt
from datetime import date
import common
import datetime
import os,csv,sys
import shutil
sys.path.append(common.LIB_DIR)
import common_profit as compf
import stg_breakout_test as breakout

class profit:
    def __init__(self,num):
        t = datetime.datetime.now()
        self.date = t.strftime("%Y%m%d%H%M%S")
        #保存フォルダルート
        self.S_DIR = os.path.join(r"C:\data\90_profit\06_output",num,self.date + "_FX")
        #保存フォルダ
        self.INPUT_DIR = r"C:\data\90_profit\05_input\FX"
        os.mkdir(str(self.S_DIR))
        #本スクリプトコピー
        shutil.copy2(__file__, self.S_DIR)

    def M15_stg(self,ETF,priod = 'MM',cnt = 1):
        t = datetime.datetime.now()
    #時間指定ネタ
    #    sql_pd = pd.read_csv( 'USDJPY_15.csv',index_col=0,parse_dates=True)
    #    td=sql_pd[sql_pd.index.hour==8]
        for code in ETF:
            print(code)
    #        para =[ i for i in range(24)]
            sql_pd = breakout.priod_edit2(code, priod)
            if len(sql_pd) > 500:
                for i in range(2, int(350 / cnt), int(50 / cnt)):
                    window = i
                    multi = 2.5
                    title = code + "_" + str(window) + "_" + str(multi) + "_ma_std.csv"
                    PL = breakout.ma_std(window, multi, sql_pd, code)
                    Equity, backreport = compf.BacktestReport(PL, title, info.S_DIR)
                for i in range(2, int(200 / cnt), int(20 / cnt)):
                    for ii in range(2, int(400 / cnt), int(50 / cnt)):
                        window0 = i
                        window9 = ii
                        if i == ii:
                            continue
                        title = code + "_" + str(window0) + "_" + str(window9) + "_ma_two.csv"
                        PL = breakout.ma_two(window0, window9, sql_pd, code)
                        Equity, backreport = compf.BacktestReport(PL, title,info.S_DIR)

                for i in range(1, int(300 / cnt), int(30 / cnt)):
                    for ii in range(int(50 / cnt), int(200 / cnt), int(100 / cnt)):
                        for iii in range(int(300 / cnt), int(3000 / cnt), int(300 / cnt)):
                            window0 = i
                            window5 = ii
                            window9 = iii
                            if i < ii < iii or i > ii > iii:
                                title = code + "_" + str(window0) + "_" + str(window5) + "_" + str(window9) + "_ma_three.csv"
                                PL = breakout.ma_three(window0, window5, window9, sql_pd, code)
                                Equity, backreport = compf.BacktestReport(PL, title,info.S_DIR)
                for i in range(5, int(100 / cnt), int(10 / cnt)):
                    for ii in range(int(10 / cnt), int(300 / cnt), int(30 / cnt)):
                        for iii in range(int(50 / cnt), int(2000 / cnt), int(100 / cnt)):
                            for iiii in range(int(500 / cnt), int(3000 / cnt), int(500 / cnt)):
                                window0 = i
                                window5 = ii
                                window9 = iii
                                window10 = iiii
                                if i > ii > iii > iiii or i < ii < iii < iiii:
                                    title = code + "_" + str(window0) + "_" + str(window5) + "_" + str(window9) + "_" + str(window10) + "_ma_four.csv"
                                    PL = breakout.ma_four(window0, window5, window9,window10, sql_pd, code)
                                    Equity, backreport = compf.BacktestReport(PL, title, info.S_DIR)

                for i in range(2, int(200 / cnt), int(50 / cnt)):
                    for ii in range(2, int(100 / cnt), int(20 / cnt)):
                        window0 = i
                        window9 = ii
                        if i == ii:
                            continue
                        title = code + "_" + str(window0) + "_" + str(window9) + "_simple.csv"
                        PL = breakout.simple(window0, window9, sql_pd, code)
                        Equity, backreport = compf.BacktestReport(PL, title,info.S_DIR)

                for i in range(2, int(200 / cnt), int(50 / cnt)):
                    for ii in range(2, int(100 / cnt), int(20 / cnt)):
                        for iii in range(2, int(100 / cnt), int(20 / cnt)):
                            for iiii in range(2, int(400 / cnt), int(50 / cnt)):
                                window0 = i
                                window9 = ii
                                f0 = iii
                                f9 = iiii
                                if i == ii or iii == iiii:
                                    continue
                                title = code + "_" + str(window0) + "_" + str(window9) + "_" + str(f0) + "_" + str(f9) + "_simple_f.csv"
                                PL = breakout.simple_f(window0, window9, f0, f9, sql_pd, code)
                                Equity, backreport = compf.BacktestReport(PL, title,info.S_DIR)
        sum_time = datetime.datetime.now() - t
        print(t,datetime.datetime.now(),sum_time)


if __name__ == "__main__":
    t = datetime.datetime.now()
    info = profit('FX')
    ETF = [ 'BTCJPY','GBPJPY', 'USDJPY', 'EURJPY','EURUSD','AUDJPY','AUDUSD', 'GBPUSD']
#    ETF = ['topixL', 'J225L', 'jpx400', 'mather', 'GOLD', 'GOMU', 'pura', 'WTI']
    info.M15_stg(ETF, "15T")
    """
    ##################CFD Daily
    df = common.select_sql('B05_cfd_stg.sqlite', 'select *,rowid from _gmo_info')
    title = list(df.columns)
    ETF = []
    for code in title:
        if code.count("_") or code == 'now':
            continue
        ETF.append(code)
    info.M15_stg(ETF,"D",10)
    ##################CFD Daily
    """
    print("end",__file__)
