import sqlite3
import pandas as pd
import urllib.request
import sys
import xlrd
import datetime
import time
import csv
import os
import requests
from bs4 import BeautifulSoup
import glob
import pandas_datareader.data as web

import ssl
ssl._create_default_https_context = ssl._create_unverified_context

import common
sys.path.append(common.LIB_DIR)

DB_USD = common.save_path('I09_stock_usd.sqlite')


class k61_DBupdate_usd(object):
    def __init__(self):
        self.send_msg = ""
        self.flag_dir = common.TDNET_FLAG

    def trol_up(self, typew, haba, LastDay, StartDay, price):
        try:
            up_cnt = [-0.3, -0.2, -0.1, -0.05, -0.02]
            if typew == "買" and price < LastDay:
                son_up = [1.4, 1.3, 1.2, 1.1, 1.05]
                for t in range(len(son_up)):
                    if StartDay * son_up[t] < LastDay or haba == up_cnt[t]:
                        return up_cnt[t]

            if typew == "売" and price > LastDay:
                son_up = [0.6, 0.7, 0.8, 0.9, 0.95]
                for t in range(len(son_up)):
                    if StartDay * son_up[t] > LastDay or haba == up_cnt[t]:
                        return up_cnt[t]
        except:
            self.send_msg += "トロール処理でエラー発生" + \
                str(StartDay) + "_" + str(price) + "\n"
        return haba

    def download_file(self, url, filename):
        print('Downloading ... {0} as {1}'.format(url, filename))
        urllib.request.urlretrieve(url, filename)

    def hist_update(self):
        browser = ""
        sqls = "select *,rowid from bybyhist where 終了日付 IS NULL or 終了日付 = ''"
        sql_pd = common.select_sql(DB_USD, sqls)
        for i, row in sql_pd.iterrows():
            common.to_number(row)
            kishi = 0
            code = row['コード']
            try:
                yahoo = common.real_stock_us(code)
            except:
                self.send_msg += code + "_YAHOO情報取得失敗" + "\n"
                continue

            # 初日確認
            try:
                row['仕掛け値'] = int(float(row['仕掛け値']))
            except:
                dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': row['日数'], 'key3': yahoo["price"],
                        'key4': row['仕切り期限日'], 'key5': yahoo["Open"], 'key6': row['タイトル'], 'key99': common.env_time()[1]}
                sqls = "UPDATE %(table)s SET 日数 = '%(key2)s', 値 = '%(key3)s',仕切り期限日 = '%(key4)s',仕掛け値 = '%(key5)s' ,更新時間 = '%(key99)s' where rowid= '%(key1)s'" % dict
                common.sql_exec(DB_USD, sqls)
                continue

            try:
                row['損切り幅'] = float(row['仕掛け値'])
            except:
                self.send_msg += row['コード'] + "_" + \
                    row['タイトル'] + "_仕掛ねチェックでエラー発生" + "\n"
                if row['損切り幅'] == '':
                    row['損切り幅'] = 0
                else:
                    continue
            # 損切切り上げ修正
            if row['損切り幅'] < 0.12 and row['損切り幅'] > 0.04 and common.date_diff(row['日付']) < -9:
                row['損切り幅'] = 0.01
            elif row['損切り幅'] == 0.01 and common.date_diff(row['日付']) < -20:
                row['損切り幅'] = -0.02

            # トロール処理
            if row['損切り幅'] <= 0.01:
                row['損切り幅'] = self.trol_up(
                    row['type'], row['損切り幅'], yahoo['Previous_Close'], row['仕掛け値'], yahoo["price"])
            # 損切チェック
            if row['損切り幅'] < 1:
                son = row['損切り幅'] * row['仕掛け値']
                if row['type'] == "買":
                    if yahoo['price'] < row['仕掛け値'] - son:
                        kishi = 1
                if row['type'] == "売":
                    if yahoo['price'] > row['仕掛け値'] + son:
                        kishi = 1
            # 10%以上で終値で下がったら決済
            if row['タイトル'] in ('高配当銘柄', '優待戦略'):
                if row['仕掛け値'] * 1.1 < row['値'] and yahoo['price'] < yahoo['LastDay']:
                    kishi = 1

            # 仕切り処理
            if row['type'] == "買":
                sum_t = round((yahoo["price"]-row["仕掛け値"]) * row['玉'], 2)
            else:
                sum_t = round((row["仕掛け値"]-yahoo["price"]) * row['玉'], 2)

            if row['日数'] <= 0 or common.date_diff(row['仕切り期限日'], common.next_day()) <= 0 or kishi == 1:
                files = glob.glob(common.save_path(common.DROP_DIR, str(code)) + '*')  # ワイルドカードが使用可能
                for file in files:
                    os.remove(file)
                if row["追加建玉"] in (2, 3):
                    row["玉"] = row["玉"] * row["追加建玉"]
                bybypara = {"code": code, "amount": row["玉"], "buysell": row['type'], "kubun": row['信用'],
                            "nari_hiki": u"成行", "settle": 1, "comment": row['タイトル']+"決済", "now": ""}
#                result,msg,browser = k92_lvs.live_main(bybypara,browser)
                self.send_msg += row['コード'] + "_" + "\n"
                dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': 99, 'key3': row['タイトル'],
                        'key4': sum_t, 'key5': row['損切り幅'], 'key99': common.env_time()[1]}
                sqls = "UPDATE %(table)s SET 終了日付 = '%(key2)s',更新時間 = '%(key99)s',損益 = '%(key4)s',損切り幅 = '%(key5)s'  where rowid = '%(key1)s'" % dict
            else:
                row['日数'] = row['日数'] - 1
                dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': row['日数'], 'key3': yahoo["price"],
                        'key4': row['仕切り期限日'], 'key5': sum_t, 'key6': row['タイトル'], 'key7': row['損切り幅'], 'key99': common.env_time()[1]}
                sqls = "UPDATE %(table)s SET 日数 = '%(key2)s', 値 = '%(key3)s',仕切り期限日 = '%(key4)s',損益 = '%(key5)s' ,更新時間 = '%(key99)s',損切り幅 = '%(key7)s' where rowid = '%(key1)s'" % dict
            common.sql_exec(DB_USD, sqls)

    def yahoo_daily(self,code_name = None):
        table_name = "kabu_list"

        if code_name is None:
            sqls = "select *,rowid from kabu_list"
            sql_pd = common.select_sql(DB_USD, sqls)
        else :
            sql_pd = pd.DataFrame({'コード': code_name}, index=[1])

        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            try:
                yahoo_info = common.real_stock_us(code)
                print(code, yahoo_info['price'])
            except:
                print(code, "NG")
                yahoo_info = {'price': '', 'Previous_Close': '', 'Open': '', 'High': '', 'Low': '', 'Week_Range52': '', 'Volume': '', 'Avg_Volume': '', 'Market_Cap': '', 'Beta': '', 'PE_Ratio_TTM': '', 'EPS_TTM': '', 'Earnings_Date': '', 'Forward_Dividend__Yield': '', 'ExDividend_Date': '', 'y1_Target_Est': ''}
            print(yahoo_info)
            # DBアップデート
            sqls = common.create_update_sql(DB_USD, yahoo_info, table_name, code) #最後の引数を削除すると自動的に最後の行

    def mente_weekly(self):
        sqls = "select *,rowid from kabu_list"
        sql_pd = common.select_sql(DB_USD, sqls)
        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            # 日付更新
            days = common.date_diff(row['updatetime'])
#            if days < -3:
            res = self.hist_check_week(DB_USD, code, row['rowid'])
            if res == -1:
                self.send_msg += str(code) + "のヒスト取得でエラーが発生しました。" + "\n"

    def hist_check_week(self, DB_USD, code, rid):
        #        try:
        val_avg_kari = {}
        high_log = {}
        today = datetime.date.today()
        result, date, open, high, low, close, volume = common.get_stock_usd(code)
        if result == -1:
            return -1
        day_c = len(date)
        for day in [700, 365, 180, 90, 30]:
            volume_avg = 0
            yest_day = today - datetime.timedelta(days=day)
            yest_day = yest_day.strftime("%Y/%m/%d")
            for ii in range(len(date)):
                if str(yest_day) > date[ii]:
                    break
#            print(yest_day,date[ii])
            if ii == 0:
                return 0
            cnt = ii
            d = date[:ii]
            o = open[:ii]
            h = high[:ii]
            l = low[:ii]
            c = close[:ii]
            v = volume[:ii]
            close_avg = float(sum([c[i] for i in range(len(c))]) / cnt)
            val_avg_kari[str(day)] = round((c[0] / close_avg), 2)
            try:
                high_log[str(day)] = round(
                    (c[0] - min(c)) / (max(c) - min(c)), 2)
            except:
                high_log[str(day)] = 0
            if day == 90:
                vora = round((max(high) - min(low)) / c[0], 3)

            if day == 30:
                volume_avg = int(sum([v[i] for i in range(len(v))]) / cnt)
                # high_log25,'key5':val_avg_kari25
                #'HighLow25' = '%(key4)s','乖離avg25' =
        dict = {'table': 'kabu_list', 'key1': rid, 'key2': val_avg_kari["90"], 'key3': val_avg_kari["180"], 'key4': val_avg_kari["365"], 'key5': val_avg_kari["700"],
                'key6': high_log["90"], 'key7': high_log["180"], 'key8': high_log["365"], 'key9': high_log["700"], 'key10': vora,
                'key11': volume_avg, 'key12': day_c, 'key13': high_log["30"], 'key14': val_avg_kari["30"], 'key99': common.env_time()[1]}
        sqls = "UPDATE %(table)s SET '乖離avg90' = '%(key2)s' ,'乖離avg180' = '%(key3)s' ,'乖離avg365' = '%(key4)s','乖離avg700' = '%(key5)s',\
        'HighLow90' = '%(key6)s' ,'HighLow180' = '%(key7)s' ,'HighLow365' = '%(key8)s','HighLow700' = '%(key9)s' ,'変動率90' = '%(key10)s' ,\
        'AVG20出来高' = '%(key11)s' ,'day_cnt' = '%(key12)s','HighLow30' = '%(key13)s','乖離avg30' = '%(key14)s','updatetime' = '%(key99)s'  where rowid = '%(key1)s'" % dict

        # ヘッダー存在チェック
        new_list = ['乖離avg90', '乖離avg180', '乖離avg365', '乖離avg700', 'HighLow90', 'HighLow180',
                    'HighLow365', 'HighLow700', '変動率90', 'AVG20出来高', 'HighLow30', '乖離avg30', 'day_cnt']
        aaa = common.column_check(DB_USD, 'kabu_list', new_list)
        common.sql_exec(DB_USD, sqls)
        return 0
#        except:
#            self.send_msg += str(code) + "でエラーが発生しました。" + "\n"
#            return -1

    def sp500_add_remove_stg(self):
        table_name = "kabu_list"
        UURL = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"
        dfs = common.read_html2(UURL, 1)  # header=0,skiprows=0(省略可能)
        for idx, row in dfs[1].iterrows():
            if idx > 10:
                break
            # SP500追加銘柄チェック
            if len(row[0]) < 5:
                cnt = 0
            else:
                cnt = 1
            if str(row[cnt]) != "nan" and str(row[cnt+1]) != "nan":
                code = row[cnt]
                dict = {'table': 'kabu_list', 'key1': code}
                sqls = "select *,rowid from %(table)s where コード = '%(key1)s' and SP500 IS NULL" % {'table': 'kabu_list', 'key1': code}
                if len(common.select_sql(DB_USD, sqls)) == 0:
                    title = "SP500入れ替え戦略追加"
                    # 重複チェック
                    sqls = "select *,rowid from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s'" % {'table': 'bybyhist', 'key1': code, 'key2': title}
                    sql_pd2 = common.select_sql(DB_USD, sqls)
                    if len(sql_pd2) > 0:
                        continue
                    # 入れ替え戦略買い
                    bybypara = {'code': code, 'amount': '100', 'buysell': u'買', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
                    bybypara["amount"] = common.ceil_usd(code, 5000)
#                    result,msg,browser = k92_lvs.live_main(bybypara,browser)
                    # 1週間後、仕切りの期限へ
                    end_day = datetime.date.today() + datetime.timedelta(days=30)
                    end_day = end_day.strftime("%Y/%m/%d")
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": code, "銘柄名": row[cnt+1], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 20, "玉": bybypara["amount"], "仕切り期限日": end_day, "追加建玉": ''}
                    bybyhist = common.add_dict_usd(code, bybyhist)
                    common.insertDB3(DB_USD, 'bybyhist', bybyhist)

            # SP500除外銘柄チェック
            if str(row[cnt+2]) != "nan" and str(row[cnt+3]) != "nan":
                code = row[cnt+2]
                dict = {'table': 'kabu_list', 'key1': code}
                sqls = "select *,rowid from %(table)s where コード = '%(key1)s' and SP500 IS NOT NULL" % {'table': 'kabu_list', 'key1': code}
                tsd = common.select_sql(DB_USD, sqls)
                if len(tsd) == 0:
                    title = "SP500入れ替え戦略削除"
                    # 重複チェック
                    sqls = "select *,rowid from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s'" % {'table': 'bybyhist', 'key1': code, 'key2': title}
                    sql_pd2 = common.select_sql(DB_USD, sqls)
                    if len(sql_pd2) > 0:
                        continue
                    # 入れ替え戦略売り
                    bybypara = {'code': code, 'amount': '100', 'buysell': u'売', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
                    bybypara["amount"] = common.ceil_usd(code, 5000)
#                    result,msg,browser = k92_lvs.live_main(bybypara,browser)
                    # 1週間後、仕切りの期限へ
                    end_day = datetime.date.today() + datetime.timedelta(days=30)
                    end_day = end_day.strftime("%Y/%m/%d")
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": code, "銘柄名": row[cnt+3], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 20, "玉": bybypara["amount"], "仕切り期限日": end_day, "追加建玉": ''}
                    bybyhist = common.add_dict_usd(code, bybyhist)
                    common.insertDB3(DB_USD, 'bybyhist', bybyhist)

    def sp500_check(self):
        # SP500 NULL
        sqls = "update kabu_list set SP500 = NULL"
        common.sql_exec(DB_USD, sqls)

        # SP500 更新
        table_name = "kabu_list"
        UURL = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"
        dfs = common.read_html2(UURL, 0)  # header=0,skiprows=0(省略可能)
        if dfs[0].columns[0] != 'Symbol':
            self.send_msg += "Symbolの項目がありません。SP500銘柄チェック" + '\n' + UURL
            return
        for idx, row in dfs[0].iterrows():
            if str(row[6]) == "nan":
                row[6] = 9999

            sqls = "UPDATE %(table)s SET SP500 = '%(key2)s' where コード = '%(key1)s'" % {'table': table_name, 'key1': row[0], 'key2': row[6]}
            common.sql_exec(DB_USD, sqls)

    def Up_stg(self):
        browser = ""
        title = '高値超え銘柄'
        sqls = "select コード, 銘柄名_英語 from %(table)s where HighLow700 > %(key0)s and day_cnt > %(key1)s and price > %(key2)s and HighLow30 > %(key3)s" \
        % {'table': 'kabu_list', 'key0': 0.99, 'key1': 20, 'key2': 5, 'key3': 0.99}
#        sqls = "select コード, 銘柄名_英語 from %(table)s "% {'table':'kabu_list','key0':0.99,'key1':20,'key2':5,'key3':0.99}
        sql_pd = common.select_sql(DB_USD, sqls)
        if len(sql_pd) > 0:
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd = common.select_sql(DB_USD, sqls)
                if len(sql_pd) > 0:
                    continue
                # 高値更新チェック
                if common.high_check1_usd(code, 30) == 1:
                    bybypara = {'code': code, 'amount': '100', 'buysell': u'買', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
                    bybypara["amount"] = common.ceil_usd(code, 5000)
                    tsd = common.kabu_search_usd(code)
#                    result,msg,browser = k92_lvs.live_main(bybypara,browser)
                    end_day = datetime.date.today() + datetime.timedelta(days=30)
                    end_day = end_day.strftime("%Y/%m/%d")
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名_英語'], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 20, "玉": bybypara["amount"], "仕切り期限日": end_day}
                    bybyhist = common.add_dict_usd(code, bybyhist)
                    common.insertDB3(DB_USD, 'bybyhist', bybyhist)
                    self.send_msg += title + "_" + row['コード'] + "\n"

    def Down_stg(self):
        browser = ""
        title = '低値超え銘柄'
        sqls = "select コード, 銘柄名_英語 from %(table)s where HighLow700 < %(key0)s and day_cnt > %(key1)s and price > %(key2)s and HighLow30 < %(key3)s" \
        % {'table': 'kabu_list', 'key0': 0.1, 'key1': 20, 'key2': 5, 'key3': 0.01}
#        sqls = "select コード, 銘柄名_英語 from %(table)s "% {'table':'kabu_list','key0':0.99,'key1':20,'key2':5,'key3':0.99}
        sql_pd = common.select_sql(DB_USD, sqls)
        if len(sql_pd) > 0:
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd = common.select_sql(DB_USD, sqls)
                if len(sql_pd) > 0:
                    continue
                # 高値更新チェック
                if common.high_check1_usd(code, 30) == -1:
                    bybypara = {'code': code, 'amount': '100', 'buysell': u'売', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
                    bybypara["amount"] = common.ceil_usd(code, 5000)
                    tsd = common.kabu_search_usd(code)
#                    result,msg,browser = k92_lvs.live_main(bybypara,browser)
                    end_day = datetime.date.today() + datetime.timedelta(days=30)
                    end_day = end_day.strftime("%Y/%m/%d")
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名_英語'], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 20, "玉": bybypara["amount"], "仕切り期限日": end_day}
                    bybyhist = common.add_dict_usd(code, bybyhist)
                    common.insertDB3(DB_USD, 'bybyhist', bybyhist)
                    self.send_msg += title + "_" + row['コード'] + "\n"

    def Dividend_stg(self):
        browser = ""
        title = '配当買い'
        sqls = "select * from %(table)s where Yield > %(key0)s and day_cnt > %(key1)s and price > %(key2)s and HighLow30 > %(key3)s" \
        % {'table': 'kabu_list', 'key0': 3, 'key1': 20, 'key2': 5, 'key3': 0.95}

#        sqls = "select コード, 銘柄名_英語 from %(table)s "% {'table':'kabu_list','key0':0.99,'key1':20,'key2':5,'key3':0.99}
        sql_pd = common.select_sql(DB_USD, sqls)
        if len(sql_pd) > 0:
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd = common.select_sql(DB_USD, sqls)
                if len(sql_pd) > 0:
                    continue
                # 高値更新チェック
                if common.high_check1_usd(code, 30) == 1:
                    bybypara = {'code': code, 'amount': '100', 'buysell': u'買', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
                    bybypara["amount"] = common.ceil_usd(code, 5000)
                    tsd = common.kabu_search_usd(code)
#                    result,msg,browser = k92_lvs.live_main(bybypara,browser)
                    end_day = datetime.date.today() + datetime.timedelta(days=30)
                    end_day = end_day.strftime("%Y/%m/%d")
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名_英語'], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 20, "玉": bybypara["amount"], "仕切り期限日": end_day}
                    bybyhist = common.add_dict_usd(code, bybyhist)
                    common.insertDB3(DB_USD, 'bybyhist', bybyhist)
                    self.send_msg += title + "_" + row['コード'] + "\n"

    def HopeBuy_stg(self):
        browser = ""
        title = '期待値買い'
        sqls = "select コード,y1_Target_Est,price,銘柄名_英語 from %(table)s where day_cnt > %(key1)s and price > %(key2)s and HighLow30 > %(key3)s" \
        % {'table': 'kabu_list', 'key1': 20, 'key2': 5, 'key3': 0.9}

#        sqls = "select コード, 銘柄名_英語 from %(table)s "% {'table':'kabu_list','key0':0.99,'key1':20,'key2':5,'key3':0.99}
        sql_pd = common.select_sql(DB_USD, sqls)
        if len(sql_pd) > 0:
            for i, row in sql_pd.iterrows():
                common.to_number(row)
                code = row['コード']
                # price×３< 期待値の条件チェック
                try:
                    if row['y1_Target_Est'] / row['price'] > 1.5:
                        pass
                    else:
                        continue
                except:
                    continue

                # 重複チェック
                sqls = "select * from %(table)s where コード = '%(key1)s' and タイトル = '%(key2)s' and (終了日付 IS NULL or 終了日付 = '')" % {'table': 'bybyhist', 'key1': code, 'key2': title}
                sql_pd = common.select_sql(DB_USD, sqls)
                if len(sql_pd) > 0:
                    continue
                # 高値更新チェック
                if common.high_check1_usd(code, 30) == 1:
                    bybypara = {'code': code, 'amount': '100', 'buysell': u'買', 'kubun': '1','nari_hiki': u'成行', 'settle': 0, 'comment': '', "comment": title, 'now': ''}
                    bybypara["amount"] = common.ceil_usd(code, 5000)
                    tsd = common.kabu_search_usd(code)
#                    result,msg,browser = k92_lvs.live_main(bybypara,browser)
                    end_day = datetime.date.today() + datetime.timedelta(days=30)
                    end_day = end_day.strftime("%Y/%m/%d")
                    # 売買履歴DBインポート
                    bybyhist = {"日付": common.env_time()[1], "タイトル": title, "コード": bybypara["code"], "銘柄名": row['銘柄名_英語'], "type": bybypara["buysell"],
                                "損切り幅": 0.05, "信用": bybypara["kubun"], "日数": 20, "玉": bybypara["amount"], "仕切り期限日": end_day}
                    bybyhist = common.add_dict_usd(code, bybyhist)
                    common.insertDB3(DB_USD, 'bybyhist', bybyhist)
                    self.send_msg += title + "_" + row['コード'] + "\n"

    def finance_week(self):
        table_name = "kabu_list"
        sqls = "select *,rowid from kabu_list"
        sql_pd = common.select_sql(DB_USD, sqls)
        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            UURL = "https://www.barchart.com/stocks/quotes/" + code + "/profile"
            dfs = common.read_html2(UURL, None) # header=0,skiprows=0(省略可能)
            if type(dfs) == int:
                continue
            dict_a = {}
            # 辞書化、DB使用不可文字除去
            if len(dfs) > 3:
                num = 4
            elif len(dfs) == 3:
                num = 2
            else:
                continue
            for ii in range(num):
                dict_w = {}
                for idx, roww in dfs[ii].iterrows():
                    if type(roww[0]) is float:
                        if "nan" == str(float(roww[0])):
                            continue
                    if type(roww[1]) is float:
                        if "nan" == str(float(roww[1])):
                            continue
                    title = common.title_edit(roww[0])
                    val = str(roww[1]).replace("%", "").replace(",", "").replace(" ", "").replace("'", "")
                    dict_w[title] = val
                dict_a.update(dict_w)
            try:
                sqls = common.create_update_sql(DB_USD, dict_a, table_name, code) #最後の引数を削除すると自動的に最後の行
            except:
                pass

    def check_new_list(self):
        # フラグ NULL
        sqls = "update kabu_list set DEL = NULL"
        common.sql_exec(DB_USD, sqls)

        AA = ["amex", "nyse", "nasdaq"]
        all_list = []
        for i in AA:
            lastfile = common.save_path(common.TEMP_DIR, i + ".csv")
            url = "https://www.nasdaq.com/screening/companies-by-name.aspx?letter=0&exchange=" + i + "&render=download"
            urllib.request.urlretrieve(url, "{0}".format(lastfile))
            # 追加銘柄確認
            df = pd.read_csv(lastfile, parse_dates=True)
            for ii, row in df.iterrows():
                code = row['Symbol'].strip()
                if code.count("^") or code.count(".") or code.count("~"):
                    continue
                tsd = common.kabu_search_usd(code)
                if len(tsd) == 0:
                    kabu_list = {"コード": code, "銘柄名_英語": row['Name'], "業種": row['Sector'], "市場": i}
                    common.insertDB3(DB_USD, 'kabu_list', kabu_list)
                    self.send_msg += code + "を追加しました。" + "\n"
                else:
                    sqls = "UPDATE %(table)s SET DEL = '%(key2)s' where コード = '%(key1)s'" % {'table': 'kabu_list', 'key1': code, 'key2': 1}
                    common.sql_exec(DB_USD, sqls)

        # 削除銘柄
        sqls = "select *,rowid from %(table)s where DEL IS NULL" % {'table': 'kabu_list'}
        sql_pd = common.select_sql(DB_USD, sqls)
        if len(sql_pd) > 0:
            self.send_msg += str(len(sql_pd)) + "個を削除しました。" + "\n"
            sqls = "delete from %(table)s where DEL IS NULL and コード NOT IN ('HYG')" % {'table': 'kabu_list'}
            common.sql_exec(DB_USD, sqls)

    def name_up(self):
        sqls = "select *,rowid from kabu_list"
        sql_pd = common.select_sql(DB_USD, sqls)
        for i, row in sql_pd.iterrows():
            aaa = row["銘柄名_英語"].replace(" ", "").replace("%", "").replace("$", "").replace("-", "").replace(",", "").replace("/", "_").replace(".", "").replace("'", "")
            if row["銘柄名_英語"] == aaa:
                pass
            else:
                sqls = "UPDATE %(table)s SET 銘柄名_英語 = '%(key2)s' where rowid = '%(key1)s'" % {'table': 'kabu_list', 'key1': row["rowid"], 'key2': aaa}
                common.sql_exec(DB_USD, sqls)

    def having_stock(self):
        # JPYレート取得
        sqls = "select *,rowid from gmofx"
        sql_pd = common.select_sql(common.save_path('I07_fx.sqlite'), sqls)
        JPY = float(sql_pd.loc[0, 'USD/JPY'])

        bybyhist = {}
        dict_sum = {'評価損益': 0, '評価損益JP': 0, '評価合計': 0, '評価合計JP': 0}
        sqls = "select *,rowid from stock_list"
        sql_pd = common.select_sql(DB_USD, sqls)
        for i, row in sql_pd.iterrows():
            code = row['コード']
            tsd = common.kabu_search_usd(code)
            if len(tsd) == 0:
                continue
            # 価格有無チェック
            try:
                bybyhist['価格'] = float(tsd['price'])
            except:
                print("価格有無チェック_R536", tsd['price'])
                continue
            bybyhist['評価損益'] = (row['価格'] - row['仕掛価格']) * row['玉']
            bybyhist['評価損益JP'] = bybyhist['評価損益'] * JPY

            # 合計計算
            dict_sum['評価損益'] += bybyhist['評価損益']
            dict_sum['評価損益JP'] += bybyhist['評価損益JP']
            dict_sum['評価合計'] += row['価格'] * row['玉']
            dict_sum['評価合計JP'] += row['価格'] * row['玉'] * JPY
            #今年の乖離率
            yyyy = common.env_time()[1][0:4]
            df = web.DataReader(code, "yahoo", yyyy + "/1/2", common.env_time()[1][0:10])
            bybyhist['P' + yyyy] = round(df.Open[len(df)-1] / df.Open[0],2)

            # 過去の株価取得
            today = datetime.date.today()
            result, date, open, high, low, close, volume = common.get_stock_usd(code)
            if result == -1:
                continue
            day_c = len(date)
            print(code)
            for day in [700, 365, 180, 90, 30]:
                yest_day = today - datetime.timedelta(days=day)
                yest_day = yest_day.strftime("%Y/%m/%d")
                for ii in range(len(date)):
                    if str(yest_day) > date[ii]:
                        bybyhist['価格' + str(day)] = close[ii]
                        bybyhist['日付' + str(day)] = date[ii]
                        break
            bybyhist = common.add_dict_usd(code, bybyhist)
            sqls = common.create_update_sql(DB_USD, bybyhist, 'stock_list', row['rowid']) #最後の引数を削除すると自動的に最後の行
        common.insertDB3(DB_USD, 'sum_stock', dict_sum)

    def split_check_us(self):  # RUBYファイルの分割チェック
        # 前日分削除
        flag_file = common.save_path(common.save_path(common.RUBY_DATA, "us"), "*.last")
        files = glob.glob(flag_file)  # ワイルドカードが使用可能

        for file in files:
            flag_file = file
            os.remove(flag_file)
            flag_file = flag_file.replace(".last", "")
            if os.path.exists(flag_file):
                os.remove(flag_file)
        UURL = "https://eoddata.com/splits.aspx"
        dfs = common.read_html2(UURL, 0)  # header=0,skiprows=0(省略可能)
        # テーブル番号検索
        num = 0
        for ii in range(len(dfs)):
            if dfs[ii].columns[0] == "Exchange":
                num = ii
                break

        t = datetime.datetime.now()
        today = t.strftime("%m/%d/%Y")

        for idx, row in dfs[num].iterrows():
            # 権利落ち日確認
            if row['Date'] == today:
                print(row['Symbol'], row['Date'])
                flag_file = common.save_path(common.RUBY_DATA, "us")
                flag_file = common.save_path(flag_file, row['Symbol']) + ".txt"
                if os.path.exists(flag_file):
                    os.rename(flag_file, flag_file + ".last")
                    self.send_msg += row['Symbol'] + "_分割銘柄削除RUBY" + "\n"

    def day_quit(self):
        sqls = "select *,rowid from bybyhist where 終了日付 = '99'"
        sql_pd = common.select_sql(DB_USD, sqls)
        for i, row in sql_pd.iterrows():
            common.to_number(row)
            code = row['コード']
            try:
                yahoo_info = common.real_stock_us(code)
                yahoo_info['Open'] = float(yahoo_info['Open'])
                row['仕掛け値'] = float(row['仕掛け値'])
            except:
                continue

            if row['type'] == "買":
                print(yahoo_info['Open'], row['仕掛け値'])
                print(type(yahoo_info['Open']), type(row['仕掛け値']))
                sum_t = (yahoo_info['Open']-row['仕掛け値']) * row['玉']
            else:
                sum_t = (row['仕掛け値']-yahoo_info['Open']) * row['玉']
                self.send_msg += row['コード'] + "_" + str(yahoo_info["Open"]) + "99損益計算エラー" + "\n"
            dict = {'table': 'bybyhist', 'key1': row['rowid'], 'key2': yahoo_info["Open"], 'key3': common.env_time()[1][:10], 'key4': sum_t, 'key5': row['タイトル'], 'key99': common.env_time()[1]}
            sqls = "UPDATE %(table)s SET 値 = '%(key2)s', 終了日付 = '%(key3)s',損益 = '%(key4)s',更新時間 = '%(key99)s' where rowid = '%(key1)s'" % dict
            common.sql_exec(DB_USD, sqls)

    def list_to_csv(self):
        code = ""
        sqls = "select *,rowid from kabu_list"
        sql_pd = common.select_sql(DB_USD, sqls)
        for i, row in sql_pd.iterrows():
            code += row['コード'] + "," + str(row['業種']) + "," + str(row['市場']) +  "," + str(row['uptime']) + "\n"

        filename = common.CODE_LIST_US
        print(filename)
        common.create_file(filename, code,"utf-8")

    def split_check_us_w(self):
        file_dir = common.save_path(common.RUBY_DATA, "us")
        files = glob.glob(common.save_path(file_dir, "*.txt"))  # ワイルドカードが使用可能
        for code_text in files:
            dir, code = os.path.split(code_text)
            df = pd.DataFrame(index=pd.date_range('2007/01/01', common.env_time()[1][0:10]))
            df = df.join(pd.read_csv(code_text,index_col=0, parse_dates=True, encoding=common.check_encoding(code_text), header=None))
            df = df.dropna()
            df.columns =['O','H','L','C','V','C2']
            try:
                df['O1']=abs(df['O'] / df['O'].shift(1)-1)
            except:
                os.remove(code_text)
                continue
            days = common.date_diff(str(df.index.max()))
            if df['O1'].max() > 0.4 or days < -5:
                print(code_text,df['O1'].max())
                os.remove(code_text)

    def kabu_search_check(self):
        for t_dir in ["kabu_search","real_stock"]:
            list_w = []
            save_dir = common.save_path(common.TEMP_DIR, t_dir)
            files = sorted(os.listdir(save_dir))
            self.send_msg += "■■■" + t_dir + "_DBコード検索不可■■■" + "\n"
            for i in files:
                full_path = os.path.join(save_dir, i)
                time_date = datetime.datetime.fromtimestamp(os.path.getmtime(full_path))
                timef = time_date.strftime("%Y/%m/%d")
                timef2 = time_date.strftime("%Y/%m/%d %H:%M:%S")
                if timef >= common.env_time()[1][0:10]:
                    list_w.append(str(timef2) + "_" + i)
                print(full_path)
                os.remove(full_path)
            for code in sorted(list_w):
                self.send_msg += code + "\n"
    def check_hist_file(self, code_name=None):
        if code_name is None:
            sqls = "select *,rowid from kabu_list"
            sql_pd = common.select_sql(DB_USD, sqls)
        else :
            sql_pd = pd.DataFrame({'コード': code_name}, index=[1])
        for i, row in sql_pd.iterrows():
            code = row['コード']
            print(code)
            end_day = datetime.date.today() - datetime.timedelta(days=5)
            end_day = end_day.strftime("%Y/%m/%d")
            rm_flag = 1
            #現行ファイルをチェック
            file_txt = common.save_path(common.RUBY_DATA, os.path.join("us", code + ".txt"))
            if os.path.exists(file_txt):
                dff = pd.read_csv(file_txt, parse_dates=True, index_col=0)
                chk_date = str(dff.index[len(dff) - 1])[:10].replace("-", "/")[:10]
                if end_day <= chk_date:#5日前より新しい
                    rm_flag = 0  #実行しない。
                    print(code,end_day , chk_date)
            if rm_flag == 1:
                if os.path.exists(file_txt):
                    os.remove(file_txt)

                #新データを読み込み
                try:
                    df = web.DataReader(code, "yahoo", "2007/1/1", common.env_time()[1][0:10])
                    df = df.rename(lambda x: str(x).replace("-", "/")[:10])
                    df = df[["Open","High","Low","Close","Volume","Adj Close"]]
                    df = df.round(2)
                    df.to_csv(file_txt)
                    print(code + "yahooよりデータ取得成功")
                except:
                    print(code + "取得失敗")

if __name__ == '__main__':
    info = k61_DBupdate_usd()
    argvs = sys.argv
    today = datetime.date.today()
    if argvs[1] == "day7":  # 700
        info.yahoo_daily()  # yahoo株価情報更新
        info.day_quit()  # hist_updateの前に実施する
        info.hist_update()
        info.sp500_add_remove_stg()  # sp500_checkよりも先に実施する。
        info.sp500_check()
        info.check_hist_file()  #RUBYで取得できないデータを取得する
        info.check_hist_file('^IXIC') #ナスダック
        info.check_hist_file('^GSPC')  #SP500
        info.check_hist_file('^DJI')

        common.mail_send(u'DBメンテ終了_USD' + argvs[1], info.send_msg)
    if argvs[1] == "weekly":  # 700
        info.list_to_csv() #RUBYのリストファイル(_stock_us.txt)作成
        info.finance_week()  # ファンダメンタル
        info.check_new_list()  # 追加銘柄、削除銘柄チェック ナスダックのホームページより
        info.split_check_us_w()
        info.mente_weekly()  # yahoo株価情報更新(週次)
        common.mail_send(u'DBメンテ終了週次_USD' + argvs[1], info.send_msg)


    if argvs[1] == "day19":  # 1900
        info.name_up()
        info.Up_stg()
        info.Down_stg()
        info.Dividend_stg()
        info.HopeBuy_stg()
        info.having_stock()
#        info.split_check_us() 後で戻す
        info.kabu_search_check()
        info.split_check_us()
        common.mail_send(u'★★日次処理終了1920_DBメンテ終了夜_USD' + argvs[1], info.send_msg)



    print("end", __file__)
