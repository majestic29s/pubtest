#!/usr/bin/env python
# -*- coding: utf-8 -*-
import datetime
import os
import numpy as np
import pandas as pd
import common


#クロスオーバー移動平均
def ma_two( window0, window9, sql_pd, code):
    m0 = sql_pd.S3_R.rolling(window0).mean().shift(1)
    m9 = sql_pd.S3_R.rolling(window9).mean().shift(1)
    y = pd.concat([sql_pd.S3_R, m0, m9], axis=1).dropna()
    y.columns=['S3_R','ma0','ma9']
    #レポート用
    N = len(y) #FXデータのサイズ
    LongPL = np.zeros(N) # 買いポジションの損益
    ShortPL = np.zeros(N) # 売りポジションの損益
    SumPL = np.zeros(N) # 売りポジションの損益
    price = np.zeros(N)
    status = np.zeros(N)

    S3_Rs = y.S3_R.values
    ma0s = y.ma0.values
    ma9s = y.ma9.values
    for i in range(len(y)):
        # 過去データよりデータ加工
        S3_R = S3_Rs[i]
        m0 = ma0s[i]
        m9 = ma9s[i]
        # 前回データよりデータ取得 status and price
        price[i] = price[i - 1]
        status[i] = status[i - 1]
        SumPL[i] = SumPL[i - 1]
        #仕切り戦略
        if m0 > m9 and status[i] < 0:  #exit short-position
            ShortPL[i] = price[i]-S3_R
            price[i]=0
            status[i]=0
        elif m0 < m9 and status[i] > 0:  #exit long-position
            LongPL[i] = S3_R-price[i]
            price[i]=0
            status[i] = 0
        #仕掛け戦略
        elif S3_R < m0 < m9 and status[i] == 0:  #entry short-position
            price[i]=S3_R
            status[i] = -1
        elif S3_R > m0 > m9 and status[i] == 0:  #entry long-position
            price[i] = S3_R
            status[i] = 1
        SumPL[i] = SumPL[i] + ShortPL[i] + LongPL[i]
    return pd.DataFrame({'LongPL':LongPL, 'ShortPL':ShortPL,'Sum':SumPL}, index=y.index)

#3つの移動平均を使った戦略
def ma_three( window0, window5, window9, sql_pd, code):
    m0=sql_pd.S3_R.ewm(span=window0).mean().shift(1)
    m5=sql_pd.S3_R.ewm(span=window5).mean().shift(1)
    m9=sql_pd.S3_R.ewm(span=window9).mean().shift(1)
    y = pd.concat([sql_pd.S3_R, m0, m5, m9], axis=1).dropna()
    y.columns=['S3_R','ma0','ma5','ma9']
    #レポート用
    N = len(y) #FXデータのサイズ
    LongPL = np.zeros(N) # 買いポジションの損益
    ShortPL = np.zeros(N) # 売りポジションの損益
    SumPL = np.zeros(N) # 売りポジションの損益
    price = np.zeros(N)
    status = np.zeros(N)

    S3_Rs = y.S3_R.values
    ma0s = y.ma0.values
    ma5s = y.ma5.values
    ma9s = y.ma9.values
    for i in range(len(y)):
        S3_R = S3_Rs[i]
        m0 = ma0s[i]
        m5 = ma5s[i]
        m9 = ma9s[i]
        # 前回データよりデータ取得 status and price
        price[i] = price[i - 1]
        status[i] = status[i - 1]
        SumPL[i] = SumPL[i - 1]
        #仕切り戦略
        if (m0 > m5 or m5 > m9 ) and status[i] < 0:  #exit short-position
            ShortPL[i] = price[i]-S3_R
            price[i]=0
            status[i]=0
        elif (m0 < m5 or m5 < m9 ) and status[i] > 0:  #exit long-position
            LongPL[i] = S3_R-price[i]
            price[i]=0
            status[i] = 0
        #仕掛け戦略
        elif S3_R < m0 < m5 < m9 and status[i] == 0:  #entry short-position
            price[i]=S3_R
            status[i] = -1
        elif S3_R > m0 > m5 > m9 and status[i] == 0:  #entry long-position
            price[i] = S3_R
            status[i] = 1

        SumPL[i] = SumPL[i] + ShortPL[i] + LongPL[i]  #レポート用
    return pd.DataFrame({'LongPL':LongPL, 'ShortPL':ShortPL,'Sum':SumPL}, index=y.index)

def ma_four( window0, window5, window9, window10, sql_pd, code):
    m0=sql_pd.S3_R.ewm(span=window0).mean().shift(1)
    m5=sql_pd.S3_R.ewm(span=window5).mean().shift(1)
    m9=sql_pd.S3_R.ewm(span=window9).mean().shift(1)
    m10=sql_pd.S3_R.ewm(span=window10).mean().shift(1)
    y = pd.concat([sql_pd.S3_R, m0, m5, m9, m10], axis=1).dropna()
    y.columns=['S3_R','ma0','ma5','ma9','ma10']
    #レポート用
    N = len(y) #FXデータのサイズ
    LongPL = np.zeros(N) # 買いポジションの損益
    ShortPL = np.zeros(N) # 売りポジションの損益
    SumPL = np.zeros(N) # 売りポジションの損益
    price = np.zeros(N)
    status = np.zeros(N)

    S3_Rs = y.S3_R.values
    ma0s = y.ma0.values
    ma5s = y.ma5.values
    ma9s = y.ma9.values
    ma10s = y.ma10.values

    for i in range(len(y)):
        S3_R = S3_Rs[i]
        m0 = ma0s[i]
        m5 = ma5s[i]
        m9 = ma9s[i]
        m10 = ma10s[i]
        # 前回データよりデータ取得 status and price
        price[i] = price[i - 1]
        status[i] = status[i - 1]
        SumPL[i] = SumPL[i - 1]  #レポート用
        #仕切り戦略
        if (m0 > m5 or m5 > m9 ) and status[i] < 0:  #exit short-position
            ShortPL[i] = price[i]-S3_R
            price[i]=0
            status[i]=0
        elif (m0 < m5 or m5 < m9 ) and status[i] > 0:  #exit long-position
            LongPL[i] = S3_R-price[i]
            price[i] = 0
            status[i] = 0
        #仕掛け戦略
        elif S3_R < m0 < m5 < m9 < m10 and status[i] == 0:  #entry short-position
            price[i]=S3_R
            status[i] = -1
        elif S3_R > m0 > m5 > m9 > m10 and status[i] == 0:  #entry long-position
            price[i] = S3_R
            status[i] = 1

        SumPL[i] = SumPL[i] + ShortPL[i] + LongPL[i]  #レポート用
    return pd.DataFrame({'LongPL':LongPL, 'ShortPL':ShortPL,'Sum':SumPL}, index=y.index)

#過去の高値・安値を用いたブレイクアウト戦略
def simple(window0, window9, sql_pd, code):
    ub0=sql_pd.S3_R.rolling(window0).max().shift(1)
    lb0=sql_pd.S3_R.rolling(window0).min().shift(1)
    ub9=sql_pd.S3_R.rolling(window9).max().shift(1)
    lb9 = sql_pd.S3_R.rolling(window9).min().shift(1)
    y = pd.concat([sql_pd.S3_R, ub0, lb0, ub9, lb9], axis=1).dropna()
    y.columns = ['S3_R', 'ub0', 'lb0', 'ub9', 'lb9']
    #レポート用
    N = len(y) #FXデータのサイズ
    LongPL = np.zeros(N) # 買いポジションの損益
    ShortPL = np.zeros(N) # 売りポジションの損益
    SumPL = np.zeros(N) # 売りポジションの損益
    price = np.zeros(N)
    status = np.zeros(N)

    S3_Rs = y.S3_R.values
    ub0s = y.ub0.values
    lb0s = y.lb0.values
    ub9s = y.ub9.values
    lb9s = y.lb9.values

    for i in range(len(y)):
        S3_R = S3_Rs[i]
        # 前回データよりデータ取得 status and price
        price[i] = price[i - 1]
        status[i] = status[i - 1]
        SumPL[i] = SumPL[i - 1]
        #仕切り戦略
        if S3_R > ub9s[i] and status[i] < 0:  #exit short-position
            ShortPL[i] = price[i] - S3_R
            price[i] = 0
            status[i] = 0
        elif S3_R < lb9s[i] and status[i] > 0:  #exit short-position
            LongPL[i] = S3_R - price[i]
            price[i] = 0
            status[i] = 0
        #仕掛け戦略
        elif S3_R < lb0s[i] < lb0s[i - 5] and status[i] == 0:  #entry short-position
            price[i]=S3_R
            status[i] = -1
        elif S3_R > ub0s[i] > ub0s[i - 5] and status[i] == 0:  #entry short-position
            price[i] = S3_R
            status[i] = 1
        SumPL[i] = SumPL[i] + ShortPL[i] + LongPL[i]  #レポート用
    return pd.DataFrame({'LongPL':LongPL, 'ShortPL':ShortPL,'Sum':SumPL}, index=y.index)

#フィルター付き高値・安値のブレイクアウト
def simple_f(window0, window9, f0, f9, sql_pd, code):
    ub0=sql_pd.S3_R.rolling(window0).max().shift(1)
    lb0=sql_pd.S3_R.rolling(window0).min().shift(1)
    ub9=sql_pd.S3_R.rolling(window9).max().shift(1)
    lb9 = sql_pd.S3_R.rolling(window9).min().shift(1)
    f0 = sql_pd.S3_R.rolling(f0).mean().shift(1)
    f9 = sql_pd.S3_R.rolling(f9).mean().shift(1)
    y = pd.concat([sql_pd.S3_R, ub0, lb0, ub9, lb9,f0,f9], axis=1).dropna()
    y.columns = ['S3_R', 'ub0', 'lb0', 'ub9', 'lb9', 'f0', 'f9']

    #レポート用
    N = len(y) #FXデータのサイズ
    LongPL = np.zeros(N) # 買いポジションの損益
    ShortPL = np.zeros(N) # 売りポジションの損益
    SumPL = np.zeros(N) # 売りポジションの損益
    price = np.zeros(N)
    status = np.zeros(N)

    S3_Rs = y.S3_R.values
    ub0s = y.ub0.values
    lb0s = y.lb0.values
    ub9s = y.ub9.values
    lb9s = y.lb9.values
    f0s = y.f0.values
    f9s = y.f9.values

    for i in range(len(y)):
        S3_R = S3_Rs[i]
        # 前回データよりデータ取得 status and price
        price[i] = price[i - 1]
        status[i] = status[i - 1]
        SumPL[i] = SumPL[i - 1]
        #仕切り戦略
        if S3_R>ub9s[i] and status[i] < 0:#exit short-position
            ShortPL[i] = price[i] - S3_R
            price[i] = 0
            status[i] = 0
        elif S3_R<lb9s[i] and status[i] > 0:#exit short-position
            LongPL[i] = S3_R - price[i]
            price[i] = 0
            status[i] = 0
        #仕掛け戦略
        elif S3_R < lb0s[i] and f9s[i] > f0s[i] and status[i] == 0:  #entry short-position
            price[i]=S3_R
            status[i] = -1
        elif S3_R > ub0s[i] and f9s[i] < f0s[i] and status[i] == 0:  #entry short-position
            price[i] = S3_R
            status[i] = 1
        SumPL[i] = SumPL[i] + ShortPL[i] + LongPL[i]  #レポート用
    return pd.DataFrame({'LongPL':LongPL, 'ShortPL':ShortPL,'Sum':SumPL}, index=y.index)

#移動平均を基準とした上限・下限のブレイクアウト
def ma_std(window,multi,sql_pd, code):
    m=sql_pd.S3_R.rolling(window).mean().shift(1)
    s = sql_pd.S3_R.rolling(window).std().shift(1)
    y=pd.concat([sql_pd.S3_R,m,s],axis=1).dropna()
    y.columns = ['S3_R', 'ma_m', 'ma_s']
    y['ub']=y.ma_m+y.ma_s*multi
    y['lb']=y.ma_m-y.ma_s*multi
    #レポート用
    N = len(y) #FXデータのサイズ
    LongPL = np.zeros(N) # 買いポジションの損益
    ShortPL = np.zeros(N) # 売りポジションの損益
    SumPL = np.zeros(N) # 売りポジションの損益
    price = np.zeros(N)
    status = np.zeros(N)

    S3_Rs = y.S3_R.values
    ma_ms = y.ma_m.values
    ubs = y.ub.values
    lbs = y.lb.values

    for i in range(len(y)):
        S3_R = S3_Rs[i]
        # 前回データよりデータ取得 status and price
        price[i] = price[i - 1]
        status[i] = status[i - 1]
        SumPL[i] = SumPL[i - 1]
        #仕切り戦略
        if S3_R > ma_ms[i] and status[i] < 0:  #exit short-position
            ShortPL[i] = price[i] - S3_R
            price[i] = 0
            status[i] = 0
        elif S3_R < ma_ms[i] and status[i] > 0:  #exit long-position
            LongPL[i] = S3_R - price[i]
            price[i] = 0
            status[i] = 0
        #仕掛け戦略
        elif S3_R < lbs[i] and status[i] == 0:  #entry short-position
            price[i]=S3_R
            status[i] = -1
        elif S3_R > ubs[i] and status[i] == 0:  #entry long-position
            price[i] = S3_R
            status[i] = 1
        SumPL[i] = SumPL[i] + ShortPL[i] + LongPL[i]
    return pd.DataFrame({'LongPL':LongPL, 'ShortPL':ShortPL,'Sum':SumPL}, index=y.index)


def priod_edit(tsd,priod):
        #       ５分間隔のデータ作成
        o = tsd.Close.resample(priod).first()
        h = tsd.Close.resample(priod).max()
        l = tsd.Close.resample(priod).min()
        c = tsd.Close.resample(priod).last()
        tsd = pd.concat([o,h,l,c],axis=1).dropna()
        tsd.columns = ["Open","High","Low","Close"]
        #乖離平均追加
        for t in [7,30,200,1000]:
#                h=tsd['High'].rolling(t).max().shift(1)
#                l=tsd['Low'].rolling(t).min().shift(1)
#                c=tsd['Close'].shift(1)
            tsd['rng'+str(t)]=round((tsd['Close'].shift(1)-tsd['Low'].rolling(t).min().shift(1))/(tsd['High'].rolling(t).max().shift(1)-tsd['Low'].rolling(t).min().shift(1)),2)
            tsd['avg'+str(t)]=round(tsd['Close'].shift(1)/tsd['Close'].rolling(t).mean().shift(1)-1,2)
        return tsd

def priod_edit2(code, priod = '15T',rows = 1000000):
    if priod == "D":
        tsd_root = common.select_sql('B05_cfd_stg.sqlite', 'select *,rowid from %(table)s where rowid > (select max(rowid) from %(table)s) - %(key1)s ' % {'table': '_gmo_info', 'key1': rows})
        c = tsd_root[code].astype(np.float64)
    elif code == 'BTCJPY':
        tsd_root = common.select_sql('I05_bitcoin.sqlite', 'select now,fx_ltp as S3_R,rowid from %(table)s where substr(now,1,10) >= "2018/01/31" and rowid > (select max(rowid) from %(table)s)  - %(key1)s' % {'table': 'btcfx2', 'key1': rows})
#        tsd_root = common.select_sql('I05_bitcoin.sqlite', 'select *,rowid from %(table)s where substr(now,1,10) >= "2018/01/31" and rowid > (select max(rowid) from %(table)s)  - %(key1)s' % {'table': 'bitflyer_BTCJPY','key1': rows})
        c = tsd_root['S3_R'].astype(np.float64)


    elif code in ['topixL','J225L','jpx400','mather']:
        tsd_root = common.select_sql('I08_futures.sqlite', 'select *,rowid from %(table)s where rowid > (select max(rowid) from %(table)s) - %(key1)s' % {'table': code,'key1': rows})
        tsd_root = tsd_root[tsd_root['現在値'] != '--']
        c = tsd_root['現在値'].astype(np.float64)
    elif code in ['GOLD','GOMU','pura','WTI']:
        tsd_root = common.select_sql('I06_cmd.sqlite', 'select *,rowid from %(table)s where rowid > (select max(rowid) from %(table)s) - %(key1)s' % {'table': code,'key1': rows})
        tsd_root = tsd_root[tsd_root['現値'] != '--']
        c = tsd_root['現値'].astype(np.float64)
    else:
        tsd_root = common.select_sql('I07_fx.sqlite', 'select *,rowid from %(table)s where rowid > (select max(rowid) from %(table)s) - %(key1)s' % {'table': 'gmofx','key1': rows})
        c = tsd_root[code[:3] + "/" + code[-3:]].astype(np.float64)
    n = tsd_root['now']
    tsd = pd.concat([n, c], axis=1)
    tsd.columns = ['now', 'S3_R'][: len(tsd.columns)]
    tsd = tsd.set_index('now')
    tsd.index = pd.to_datetime(tsd.index)
    #期間を変更する
    #12H ,15T,D,W,M
    o = tsd.S3_R.resample(priod).first().dropna()
    tsd = pd.concat([o], axis=1)
    if rows != 1000000:
        return tsd
    #乖離平均追加
    for t in [7,30,200,1000]:
        tsd['rng'+str(t)]=round((tsd['S3_R'].shift(1)-tsd['S3_R'].rolling(t).min().shift(1))/(tsd['S3_R'].rolling(t).max().shift(1)-tsd['S3_R'].rolling(t).min().shift(1)),2)
        tsd['avg'+str(t)]=round(tsd['S3_R'].shift(1)/tsd['S3_R'].rolling(t).mean().shift(1)-1,3)
    return tsd

def priod_edit2_csv(code, priod='15T', rows=1000000):
    file_name = r'C:\data\90_profit\05_input\FX\\' + code[:3] + "_" + code[-3:] + '_M15.csv'
    tsd_root = pd.read_csv(file_name, parse_dates=True, encoding="cp932", header=0)
    c = tsd_root['Open'].astype(np.float64)
    n = tsd_root['Time']
    tsd = pd.concat([n, c], axis=1)
    tsd.columns = ['now', 'S3_R'][: len(tsd.columns)]
    tsd = tsd.set_index('now')
    tsd.index = pd.to_datetime(tsd.index)
    #期間を変更する
    #12H ,15T,D,W,M
    o = tsd.S3_R.resample(priod).first().dropna()
    tsd = pd.concat([o], axis=1)
    return tsd[120000:] #2009移行のデータ


def delete_rows(ETF,DAY):
    if os.name == "nt":
        for code in ETF:
            if code in ['topixL','J225L','jpx400','mather']:
                sqls = 'delete from %(table)s where substr(now,1,10) >= "%(key1)s"' % {'table': code, 'key1': DAY}
                common.sql_exec('I08_futures.sqlite', sqls)
            elif code in ['GOLD','GOMU','pura','WTI']:
                sqls = 'delete from %(table)s where substr(now,1,10) >= "%(key1)s"' % {'table': code,'key1': DAY}
                common.sql_exec('I06_cmd.sqlite', sqls)
            else:
                sqls = 'delete from %(table)s where substr(now,1,10) >= "%(key1)s"' % {'table': 'gmofx','key1': DAY}
                common.sql_exec('I07_fx.sqlite', sqls)
            print(sqls)


if __name__ == "__main__":
    t = datetime.datetime.now()
    code = 'USDJPY'
    ETF = [ 'BTCJPY','GBPJPY','AUDJPY', 'USDJPY', 'EURJPY','AUDUSD', 'GBPUSD', 'EURUSD']
#    ETF = ['topixL', 'J225L', 'jpx400', 'mather', 'GOLD', 'GOMU', 'pura', 'WTI']

#時間指定ネタ
#    tsd = pd.read_csv( 'USDJPY_15.csv',index_col=0,parse_dates=True)
#    td=tsd[tsd.index.hour==8]
#    for code in ETF:
#    code = u'BTCJPY'
    window0 = 10
    window5 = 50
    window9 = 7
    window10 = 200
    f0 = 70
    f9 = 80
    sql_pd = priod_edit2_csv(code, '15T')  #12H ,15T,D,W,M
    aaa = sql_pd[120000:]

#    PL = ma_two(window0, window9, sql_pd, code)
#    PL = ma_three(window0, window5, window9, sql_pd, code)
#    PL = ma_four(window0, window5, window9,window10, sql_pd, code)
    PL = simple(window0, window9, sql_pd, code)
    PL = simple_f(window0, window9, f0, f9, sql_pd, code)

    window = 300
    multi = 2.5
#    PL = ma_std(window, multi, sql_pd, code)
    PL.to_csv("result.csv")

    sum_time = datetime.datetime.now() - t
    print(t,datetime.datetime.now(),sum_time)
    print("end",__file__)