#!/usr/bin/env python
# -*- coding: utf-8 -*-
import warnings
warnings.filterwarnings('ignore')  # 実行上問題ない注意は非表示にする

# サポートベクターマシーンのimport
from sklearn import svm
# train_test_splitのimport
from sklearn.model_selection import train_test_split
# Pandasのimport
import pandas as pd
import numpy as np
# グリッドサーチのimport
from sklearn.model_selection import GridSearchCV
# 機械学習ライブラリ
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score,classification_report
#モデルの保存・読み込み
from sklearn.externals import joblib
import pickle

import os, csv, sys, datetime
import shutil
import common
sys.path.append(common.LABO_DIR)
import common_sklearn as sk
import common_profit as compf


class scikit_learn:
    def __init__(self, num):
        self.num = num
        self.code = ""
        self.report = {}
        self.df = pd.DataFrame([], columns=["code","histrange" ,"model" ,"tran", "pred"])
        t = datetime.datetime.now()
        self.date = t.strftime("%Y%m%d%H%M%S")
        #保存フォルダルート
        self.S_DIR = os.path.join(r"C:\data\90_profit\06_output", num, self.date)
        os.mkdir(str(self.S_DIR))
        #本スクリプトコピー
        shutil.copy2(__file__, self.S_DIR)

    def data_exec2(self, x_data, y_data, Change=2, hist_rang=1):  #何日分使うか決める nday

        # 各列を変化率へ一括変換
        x_data = sk.RateOfChange(x_data, Change, hist_rang)  # 第二引数 整数2の場合おおよそ-1.0～1.0の範囲 第三引数 何日まえからの変化率
        #x_data = self.RateOfChange(x_data,'MinMax',hist_rang) #正規化
        #x_data = self.RateOfChange(x_data,'Standard',hist_rang) #標準化

        X_train, X_test, y_train, y_test =train_test_split(x_data, y_data, train_size=0.8,test_size=0.1,random_state=1)
        # 決定技モデルの訓練
        clf_2 = DecisionTreeClassifier(max_depth=5)

        # grid searchでmax_depthの最適なパラメータを決める
        #k=10のk分割交差検証も行う
        params = {'max_depth': [2, 5, 10, 20]}

        grid = GridSearchCV(estimator=clf_2,
                            param_grid=params,
                            cv=10,
                            scoring='roc_auc')
        grid.fit(X_train, y_train)
        for r, _ in enumerate(grid.cv_results_['mean_test_score']):
            print("%0.3f +/- %0.2f %r"
                % (grid.cv_results_['mean_test_score'][r],
                    grid.cv_results_['std_test_score'][r] / 2.0,
                    grid.cv_results_['params'][r]))
        print('Best parameters: %s' % grid.best_params_)
        print('Accuracy: %.2f' % grid.best_score_)

        #grid searchで最適だったパラメータを使って学習する
        clf_2 = grid.best_estimator_
        clf_2 = clf_2.fit(X_train, y_train)
        #モデルを保存する。
        filename = os.path.join(self.S_DIR, self.code.replace("/", "") + "_" + str(self.num) + "_" + str(Change) + "_" + '_model.sav')
#        joblib.dump(clf_2, filename)
        pickle.dump(clf_2, open(filename, 'wb'))
        pred_test_2 = clf_2.predict(X_test)
        """
        #重要度の高い素性を表示
        importances = clf_2.feature_importances_
        indices = np.argsort(importances)[::-1]

        for f in range(X_train.shape[1]):
            print("%2d) %-*s %f" % (f + 1, 30,
                                    x_data.columns[1+indices[f]],
                                    importances[indices[f]]))
        """
        #テストデータ 正解率
#        print(accuracy_score(y_test, pred_test_2))
#        print(classification_report(y_test, pred_test_2))
        addRow = pd.Series([info.code,
                            self.num,
                            Change,
                            grid.best_score_,
                            accuracy_score(y_test, pred_test_2)],
                            index=self.df.columns)
        self.df = self.df.append(addRow, ignore_index=True)
        filename = os.path.join(self.S_DIR , "MODEL_SCORE.csv")
        self.df.to_csv(filename,encoding = 'cp932')

        return accuracy_score(y_test, pred_test_2)

    def main2(self, x_data, code='USD/JPY', nday=None):
        #使うデータ
        if nday is not None:
            x_data = x_data[-nday:]
        y_data = x_data['diff']
        del x_data['diff']

#            c = df_info[code]
#            df_ = pd.concat([c], axis=1)
#            df_.columns = [code]
        for i in range(1, 3):
            self.num = i
            print(code, nday, "------------")
            for ttype in [2,'MinMax','Standard']:
                res = info.data_exec2(x_data, y_data, ttype, i)

if __name__ == "__main__":
    info = scikit_learn('model')
    df_info = sk.fx_data()  #いらないデータやNoneの補修など実施
    for code in df_info.columns:
        info.code = code
        df = sk.create_y(code, df_info.copy(), -1)  #最後の引数は何日後の予測をするか？
        x_data = sk.add_avg(df, code)
        print("---------------",len(x_data.columns))
#        for nday in range(100,5000,200):
        info.main2(x_data, code)
