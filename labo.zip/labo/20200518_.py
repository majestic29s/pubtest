#!/usr/bin/env python
# -*- coding: utf-8 -*-
#https://qiita.com/shiroino11111/items/f812938fbbba7123fbcc
#精度６７％のディープラーニング株価予測モデル_1

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
#from keras.models import Sequential
#from keras.layers import Dense,  LSTM
#from keras import metrics
#from sklearn.preprocessing import MinMaxScaler
#from sklearn.metrics import accuracy_score,classification_report
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.externals import joblib
from sklearn.model_selection import GridSearchCV

import common ,sys
sys.path.append(common.LABO_DIR)
import common_sklearn as sk
import datetime,os,shutil

search_params = {
    'n_estimators' : [10, 20, 30, 40, 50, 100, 200, 300],
    'max_features': [None, 'auto', 'log2'],
    'max_depth': [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
    'class_weight': [None, 'balanced'],
    'random_state' : [42]
    }

class scikit_learn:
    def __init__(self, num):
        self.num = num
        self.code = ""
        self.report = {}
        self.df = pd.DataFrame([], columns=["code","histrange" ,"model" ,"tran", "pred"])
        t = datetime.datetime.now()
        self.date = t.strftime("%Y%m%d%H%M%S")
        #保存フォルダルート
        self.S_DIR = os.path.join(r"C:\data\90_profit\06_output", num, self.date)
        os.mkdir(str(self.S_DIR))
        #本スクリプトコピー
        shutil.copy2(__file__, self.S_DIR)

    def main(self, x_data, code):
        x_data['close+1'] = x_data[code].shift(-4).astype(np.float64) / x_data[code].astype(np.float64) - 1

        x_data['diff'] = x_data['close+1'].apply(lambda x: -1 if x < 0 else 1)
        del x_data['close+1']
        x_data = x_data.dropna(subset=['diff'])#targetに欠損値のある行を削除
        x_data = x_data.fillna(x_data.mean())#欠損値を劣後tの平均値で埋める

        last_col = len(x_data.columns) - 1

        y_data = x_data.iloc[:, last_col]

        x_data = x_data.iloc[:, :last_col]
        x_data = sk.RateOfChange(x_data, 'MinMax', 1)

        X_train,X_test,y_train,y_test = train_test_split(x_data,y_data)

        #学習宇モデルの構築
        print('学習宇モデルの構築')
        forest = RandomForestClassifier()
        grid = GridSearchCV(forest, search_params, cv=3)
        grid.fit(X_train, y_train)

        #学習結果表示
        print("Grid-Search with accuray")
        print("Best parameters:", grid.best_params_)
        print("Test set score {:.2f} ".format(grid.score(X_test, y_test)))

        filename = os.path.join(self.S_DIR, self.code.replace("/", "") + "_" + str(self.num) + "_" + '_model.pkl')
        joblib.dump(grid.best_estimator_,filename)

        print(str(code) + " : モデル保存完了")


if __name__ == "__main__":
    info = scikit_learn('model')
    df_info = sk.fx_data() #いらないデータやNoneの補修など実施
    for code in df_info.columns:
        print(code)
        x_data = sk.add_avg(df_info.copy(), code)
        info.main(x_data,code)
