#!/usr/bin/env python
# -*- coding: utf-8 -*-
from selenium import webdriver
import datetime
import re
from bs4 import BeautifulSoup
import inspect
import sys
import traceback
import os
from time import sleep
# 独自モジュールインポート
import common
sys.path.append(common.LIB_DIR)

# passconfig
import configparser
config = configparser.ConfigParser()
config.read([common.PASS_FILE])
USER_ID = config.get('hokushin', 'USER_ID')
PASSWORD = config.get('hokushin', 'PASSWORD')
DBCOMM = common.save_path('I06_cmd.sqlite')


class hokushin:
    def __init__(self, num):
        self.num = num
        self.code_list = {"東京ガソリン": "OIL", "東京金": "GOLD","東京白金": "pura", "東京ゴム": "GOMU", "東京コーン": "COOM", "東京原油": "WTI"}
        t = datetime.datetime.now()
        self.date = t.strftime("%Y%m%d%H%M")
        self.timef = t.strftime("%Y/%m/%d %H:%M:%S")
        self.empty_dict = {}
        self.error_msg = ""

    def main_info(self):
        # ログインエラー対応 5回試行
        for i in range(5):
            try:
                browser = self.login()
                break
            except:
                sleep(60)
        self.info_get(browser)

    def login(self):
        # 定数設定
        SITE_URL = 'https://www.hd-station.net/m/default.asp'
        browser = webdriver.PhantomJS()

        # ログイン画面にアクセス
        browser.get(SITE_URL)
        # ログイン処理
        uid = browser.find_element_by_name('LID')
        password = browser.find_element_by_name('LPW')
        uid.send_keys(USER_ID)
        password.send_keys(PASSWORD)
        for i in browser.find_elements_by_xpath("//*[@type='submit']"):
            i.click()
        browser.find_element_by_name('btnOK').click()
        return browser

    def info_get(self, browser):
        for k, v in self.code_list.items():
            for i in range(3):
                browser.find_element_by_link_text('[3]相場情報').click()
                pref_select = browser.find_elements_by_css_selector('select[name=SB]')
                print(k)
                pref_select[0].send_keys(k)
                browser.find_element_by_name('show').click()
                self.empty_dict = {}
                for m in re.finditer(r'(..?) &nbsp;(.+?)<br>', browser.page_source, re.UNICODE):
                    self.empty_dict[m.groups()[0]] = m.groups()[1].replace("&nbsp;", "").replace(",", "")
                filename = common.save_path(r"02_comm", v + ".csv")
                # HTTP500エラー対応
                try:
                    assert "D-mobile" in browser.title
                except:
                    browser.quit()
                    browser = self.login()
                    continue
                # 前月に差し替え対応
                if self.empty_dict == {}:
                    pref_select = browser.find_elements_by_css_selector('select[name=SBT]')
                    pref_select[0].send_keys(common.get_lastrow(filename, 1))
                    browser.find_element_by_name('submit').click()
                    for m in re.finditer(r'(..?) &nbsp;(.+?)<br>', browser.page_source, re.UNICODE):
                        self.empty_dict[m.groups()[0]] = m.groups()[1].replace("&nbsp;", "").replace(",", "")
                if len(self.empty_dict['限月']) < 4:
                    continue
                self.save_dict(self.empty_dict, filename, v)
                browser.find_element_by_link_text('[0]メインメニューへ').click()
                break

    def save_dict(self, empty_dict, filename, table):
        val_list = {"限月": 0, "始値": 0, "高値": 0, "安値": 0, "現値": 0,"売気": 0, "買気": 0, "歩１": 0, "歩２": 0, "出来": 0}
        # ヘッダー追加

        if os.path.exists(filename) == False:
            with open(filename, 'w', encoding="cp932") as f:
                f.write("更新日,")
            for k in val_list.keys():
                with open(filename, 'a', encoding="cp932") as f:
                    f.write(k + ",")
            with open(filename, 'a', encoding="cp932") as f:
                f.write("\n")
        with open(filename, 'a', encoding="cp932") as f:
            f.write(self.timef + ",")
        # 2列目からデータ挿入
        db_dict = {}
        for kk, vv in val_list.items():
            for k, v in empty_dict.items():
                if k.count('限月'):
                    val_list[kk] = v
                    db_dict[kk] = v
                elif k == kk:
                    val_list[kk] = v
                    db_dict[kk] = v
            with open(filename, 'a', encoding="cp932") as f:
                f.write(str(val_list[kk]) + ",")
        with open(filename, 'a', encoding="cp932") as f:
            f.write("\n")
        # 現値の空白数字など対応
        if val_list['現値'][0:1] == "*":
            val_list['現値'] = val_list['現値'][1:]
        elif val_list['現値'] == "":
            val_list['現値'] = val_list['売気']

        try:
            val_list['現値'] = float(val_list['現値'])
        except:
            val_list['現値'] = val_list['売気']
        # DBへのインポート
        common.insertDB3(DBCOMM, table, db_dict)


if __name__ == "__main__":
    info = hokushin(0)
    info.main_info()
    print("end")
