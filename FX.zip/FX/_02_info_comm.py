#!/usr/bin/env python
# -*- coding: utf-8 -*-
from selenium import webdriver
import datetime
import re
import sys
from time import sleep
# 独自モジュールインポート
import common
sys.path.append(common.LIB_DIR)

# passconfig
import configparser
config = configparser.ConfigParser()
config.read([common.PASS_FILE])
USER_ID = config.get('hokushin', 'USER_ID')
PASSWORD = config.get('hokushin', 'PASSWORD')
DBCOMM = common.save_path('I06_cmd.sqlite')


class hokushin:
    def __init__(self, num):
        self.num = num
        self.code_list = {"東京ガソリン": "OIL", "東京金": "GOLD","東京白金": "pura", "東京ゴム": "GOMU", "東京コーン": "COOM", "東京原油": "WTI"}
        self.empty_dict = {}
        self.error_msg = ""

    def main_info(self):
        # ログインエラー対応 5回試行
        for i in range(5):
            try:
                browser = self.login()
                break
            except:
                sleep(60)
        self.info_get(browser)

    def login(self):
        # 定数設定
        SITE_URL = 'https://www.hd-station.net/m/default.asp'
        browser = webdriver.PhantomJS()

        # ログイン画面にアクセス
        browser.get(SITE_URL)
        # ログイン処理
        uid = browser.find_element_by_name('LID')
        password = browser.find_element_by_name('LPW')
        uid.send_keys(USER_ID)
        password.send_keys(PASSWORD)
        for i in browser.find_elements_by_xpath("//*[@type='submit']"):
            i.click()
        browser.find_element_by_name('btnOK').click()
        return browser

    def info_get(self, browser):
        for k, v in self.code_list.items():
            for i in range(3):
                browser.find_element_by_link_text('[3]相場情報').click()
                pref_select = browser.find_elements_by_css_selector('select[name=SB]')
                print(k)
                pref_select[0].send_keys(k)
                browser.find_element_by_name('show').click()
                self.empty_dict = {}
                for m in re.finditer(r'(..?) &nbsp;(.+?)<br>', browser.page_source, re.UNICODE):
                    self.empty_dict[m.groups()[0]] = m.groups()[1].replace("&nbsp;", "").replace(",", "")
                # HTTP500エラー対応
                try:
                    assert "D-mobile" in browser.title
                except:
                    browser.quit()
                    browser = self.login()
                    continue
                # 前月に差し替え対応
                if self.empty_dict == {}:
                    pref_select = browser.find_elements_by_css_selector('select[name=SBT]')
                    pref_select[0].send_keys(common.get_lastrow(filename, 1))
                    browser.find_element_by_name('submit').click()
                    for m in re.finditer(r'(..?) &nbsp;(.+?)<br>', browser.page_source, re.UNICODE):
                        self.empty_dict[m.groups()[0]] = m.groups()[1].replace("&nbsp;", "").replace(",", "")
                if len(self.empty_dict['限月']) < 4:
                    continue
                self.save_dict(self.empty_dict,  v)
                browser.find_element_by_link_text('[0]メインメニューへ').click()
                break

    def save_dict(self, empty_dict,  table_name):
        columns = ["限月", "始値", "高値", "安値", "現値","売気", "買気", "歩１", "歩２", "出来"]
        # 2列目からデータ挿入
        dict_w = {}
        for col in columns:
            for k, v in empty_dict.items():
                if k.count('限月'):
                    dict_w[col] = v
                elif k == col:
                    dict_w[col] = v
        # DBへのインポート
        common.insertDB3(DBCOMM, table_name, dict_w,"Dupl_CHK")


if __name__ == "__main__":
    info = hokushin(0)
    info.main_info()
    print("end")
